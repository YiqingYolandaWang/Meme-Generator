from .IngestorInterface import IngestorInterface
from .Quote import QuoteModel
from typing import List
from .Docx import DocxIngestor
from .CSV import CSVIngestor
from .Text import TextIngestor
from .PDF import PDFIngestor

class Ingestor(IngestorInterface):
    """Comprises a list of different ingestors for reading different file formats."""
    
    ingestors = [DocxIngestor, CSVIngestor, TextIngestor, PDFIngestor]

    @classmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        """Select the appropriate helper for a given file based on filetype."""
        for ingestor in cls.ingestors:
            if ingestor.can_ingest(path):
                return ingestor.parse(path)
