import subprocess
import random
import os
from typing import List
from .IngestorInterface import IngestorInterface
from .Quote import QuoteModel


class PDFIngestor(IngestorInterface):
    """This class inherients from IngestorInterface."""
    allowed_extension = ['pdf']

    @classmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        if not cls.can_ingest(path):
            raise Exception(f'cannot ingest {path}')

        tmp = f"./tmp{random.randint(0,100000000)}.txt"
        call = subprocess.call(['pdftotext', path, tmp])

        file_Ref = open(tmp, "r")
        quotes = []
        for line in file_Ref.readlines():
            line = line.strip('\n\r').strip()
            if len(line) > 0:
                parsed = line.split('-')
                quote = QuoteModel(str(parsed[0]), str(parsed[1]))
                quotes.append(quote)
        file_Ref.close()
        os.remove(tmp)

        return quotes
