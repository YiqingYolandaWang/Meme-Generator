from typing import List
from .IngestorInterface import IngestorInterface
from .Quote import QuoteModel
import docx


class DocxIngestor(IngestorInterface):
    """A class inherits from IngestorInterface and creates a list of quotes"""
    allowed_extension = ['docx']

    @classmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        """Parses an accepted file and returns a list of quotes."""
        if not cls.can_ingest(path):
            raise Exception(f'cannot ingest {path}')

            quotes = []
            doc = docx.Document(path)

            for para in doc.paragraphs:
                if para.text != "":
                    content = para.text.split('-')
                    quote = QuoteModel(str(content[0]), str(content[1]))
                    quotes.append(quote)

            return quotes
