from PIL import Image, ImageDraw, ImageFont
import random
import textwrap

class MemeEngine():
    """"""
    def __init__(self, output_dir:str):
        """Show where to save the generated images."""
        self.output_dir = output_dir

    def make_meme(self, img_path, text, author, width=500) -> str:
        """Create a meme.
        
        Arguments:
            img_path {str} -- the file location for the image.
            text {str} -- the quote.
            author {str} -- the author of the quote.
            width {int} -- The pixel width value. Default=500.
        Returns:
            str -- the path to the manipulated image.
        """
        with Image.open(img_path) as img:
            ratio = width/float(img.size[0])
            height = int(ratio*float(img.size[1]))
            new_img = img.resize((width, height))

            draw = ImageDraw(new_img)
            wrapped_text = textwrap.fill(text=f'{text} - {author}')
            fnt = ImageFont.truetype("./fonts/LilitaOne-Regular.ttf")
            draw.text((10,20), wrapped_text, font=fnt, fill='black')
            
            out_path = f'./static/{random.randint(0,1000).png}'
            new_img.save(out_path)
            return new_img
