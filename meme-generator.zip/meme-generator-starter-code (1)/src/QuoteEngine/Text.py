from typing import List
from .IngestorInterface import IngestorInterface
from .Quote import QuoteModel


class TextIngestor(IngestorInterface):
    """This class inherites from IngestorInterface."""
    allowed_extension = ['text']

    @classmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        """Parse an accepted file and returns a list of quotes."""
        if not cls.can_ingest(path):
            raise Exception(f'cannot ingest {path}')

        quotes = []
        file = open(path, 'r')
        for line in file.readlines():
            content = line.strip().split("-")
            quote = QuoteModel(content[0], content[1])
            quotes.append(quote)

        return quotes
