from .Ingestor import Ingestor
from .Docx import DocxIngestor
from .CSV import CSVIngestor
from .PDF import PDFIngestor
from .Text import TextIngestor
from .Quote import QuoteModel
