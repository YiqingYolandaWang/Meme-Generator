class QuoteModel():
    def __init__(self, body: str, author: str):
        """Create a new QuoteModel."""
        self.body = body
        self.author = author


    def __repr__(self):
        """return "This is a quote body" - Author"""
        return f'QuoteModel(body={self.body}, author={self.author})'


    def __str__(self):
        """return 'str(self)'."""
        return self.body + " - " + self.author
