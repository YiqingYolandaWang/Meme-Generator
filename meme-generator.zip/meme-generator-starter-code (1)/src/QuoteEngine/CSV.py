from typing import List
from .IngestorInterface import IngestorInterface
from .Quote import QuoteModel
import csv
import pandas as pd

class CSVIngestor(IngestorInterface):
    """A class inherites from IngestorInterface. """
    allowed_extension = ['csv']

    @classmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        """Parse an accepted file and returns a list of quotes"""
        if not cls.can_ingest(path):
            raise Exception(f"cannot ingest {path}")
        quotes = []
        data = pd.read_csv(path, header=0)
        for index, row in data.iterrows():
            quote = QuoteModel(row['body'].strip(), row['author'].strip())
            quotes.append(quote)

        return quotes
