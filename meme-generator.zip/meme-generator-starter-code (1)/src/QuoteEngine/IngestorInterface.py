from abc import ABC, abstractmethod
from typing import List
from .Quote import QuoteModel


class IngestorInterface(ABC):
    """An abstract base class.

    it is used to determined whether the files are ingestiable and be parsed
    for quotes.
    """
    allowed_extension = []

    @classmethod
    @abstractmethod
    def can_ingest(cls, path: str) -> bool:
        '''This class is to check whether the file is ingestiable'''
        pathEnd = path.split(".")[-1]
        return pathEnd in cls.allowed_extension

    def parse(cls, path: str) -> List[QuoteModel]:
        """This class is to get inofrmation from the file."""
        pass
